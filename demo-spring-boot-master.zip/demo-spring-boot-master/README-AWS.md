# Demo - Hello World
Demo - Hello World

# Install Docker Desktop
- https://docs.docker.com/docker-for-windows/install/
- https://docs.docker.com/docker-for-mac/install/
```
$ docker version
```

# Maven
```
$ mvn clean package
```

# Docker-Compose
```
$ docker-compose -f docker-compose-local.yml up
```

# Docker Images
```
$ docker images
```

# AWS
- https://towardsdatascience.com/deploying-a-docker-container-with-ecs-and-fargate-7b0cbc9cd608

## AWS - Create Free Tier Account
- https://aws.amazon.com/free

## AWS Console - Identity and Access Management (IAM)
- https://console.aws.amazon.com
```
Agregar usuario para que acceda mediante programación
AdministratorAccess only for testing purposes
```

## AWS CLI Setup
- https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-windows.html
- https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2-mac.html

## AWS CLI
```
$ aws --version
$ aws configure
$ aws iam list-users
```

## AWS CLI - ECR
```
$ aws ecr get-login-password --region us-east-2 | docker login --username AWS --password-stdin {aws-account-id}.dkr.ecr.us-east-2.amazonaws.com
$ aws ecr get-login-password --region us-east-2 | docker login --username AWS --password-stdin 899150741402.dkr.ecr.us-east-2.amazonaws.com

$ aws ecr create-repository --repository-name demo-spring-boot

$ docker tag {docker-image-name}:latest {aws-account-id}.dkr.ecr.us-east-2.amazonaws.com/demo-spring-boot
$ docker tag demo-spring-boot:latest 899150741402.dkr.ecr.us-east-2.amazonaws.com/demo-spring-boot

$ docker push {aws-account-id}.dkr.ecr.us-east-2.amazonaws.com/demo-spring-boot
$ docker push 899150741402.dkr.ecr.us-east-2.amazonaws.com/demo-spring-boot
```

## AWS Console - ECS
```
1. Crear un cluster (Networking only)
2. Crear un task definition (Fargate)
3. Ejecutar task
```

## AWS Console - App Runner