# Deployment to IBM Cloud Foundry
Deployment to IBM Cloud Foundry

# Maven
```
$ mvn clean package
```

# Docker-Compose
```
$ docker-compose -f docker-compose-local.yml up
```

## SingUp

```
https://ibm.com/academic
```

## Login

```
https://cloud.ibm.com/login
```

## Download Cloud Foundry CLI

```
https://github.com/cloudfoundry/cli/releases
```

## Login to IBM Cloud Foundry

```
$ cf login
API endpoint: https://api.us-south.cf.cloud.ibm.com
Email: ebautistau@unmsm.edu.pe
Password: YourStrongPasswordHere
```

## Deploy App

```
$ cf push
- https://demo-spring-boot-ebautista.mybluemix.net
```

## List Apps

```
$ cf apps
```

## Scale Out

```
$ cf scale <app-name> -i 2
$ cf scale <app-name> -i 3
$ cf scale <app-name> -i 8

$ cf scale demo-spring-boot-ebautista -i 8
$ cf scale demo-spring-boot-ebautista -i 1
```

## Scale Up - Memory

```
$ cf scale <app-name> -m 128M
$ cf scale <app-name> -m 256M
$ cf scale <app-name> -m 512M
$ cf scale <app-name> -m 1G
$ cf scale <app-name> -m 2G
$ cf scale <app-name> -m 3G
$ cf scale <app-name> -m 4G

$ cf scale demo-spring-boot-ebautista -m 4GB
```

## Scale Up - Disk

```
$ cf scale <app-name> -k 2G
$ cf scale demo-spring-boot-ebautista -k 2GB
```

## Delete App

```
$ cf delete <app-name> -r -f
$ cf delete demo-spring-boot-ebautista -r -f
```
