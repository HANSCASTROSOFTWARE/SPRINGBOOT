# Demo - Hello World
Demo - Hello World

# Install Docker Desktop
- https://docs.docker.com/docker-for-windows/install/
- https://docs.docker.com/docker-for-mac/install/
```
$ docker version
```

# Maven
```
$ mvn clean package
```

# Docker-Compose
```
$ docker-compose -f docker-compose-local.yml up
```

# Docker Images
```
$ docker images
```

# Azure
- https://azure.microsoft.com/es-es/global-infrastructure/geographies

## Azure - Create Free Account
- https://azure.microsoft.com/en-us/free/students
- https://azure.microsoft.com/en-us/free
- https://portal.azure.com

## Azure CLI Setup
- https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
- https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli
- https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-macos

## Azure CLI
```
$ az upgrade
$ az version
$ az login
$ az account list-locations -o table
$ az group create -n UNMSM-TSW -l southcentralus
$ az acr create -g UNMSM-TSW -n demospringbootebautista --sku Basic --admin-enabled true
$ az acr login -n demospringbootebautista
$ az acr show -n demospringbootebautista --query loginServer --output tsv
  ->demospringbootebautista.azurecr.io
$ docker image ls
$ docker tag demo-spring-boot:latest demospringbootebautista.azurecr.io/demo-spring-boot:latest
$ docker push demospringbootebautista.azurecr.io/demo-spring-boot:latest
$ az acr repository list -n demospringboot -o table
$ az acr repository show-tags -n demospringboot --repository demo-spring-boot -o table
```

## Create App Service
- ebautista

## CLI appsettings
```
$ az webapp config appsettings set --resource-group UNMSM-TSW --name ebautista --settings WEBSITES_PORT=8080
$ az webapp config appsettings set --resource-group UNMSM-TSW --name ebautista --settings ENVIRONMENT=production
```
- Restart appservice to take effect the config appsettings
```
$ az acr repository delete -n demospringboot -t demo-spring-boot:latest
$ az group delete -n UNMSM-TSW
$ az logout
```